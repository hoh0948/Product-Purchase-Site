#ifndef KIOSK_H
#define KIOSK_H

#include <string>
#include <vector>
#include <map>
#include <chrono>
// Product Ŭ���� ����
class Product {
public:
    std::string name;
    double price;
    std::string category;
    std::map<std::string, std::string> attributes;

    Product(const std::string& n, double p, const std::string& c)
        : name(n), price(p), category(c) {
    }
};

struct CartItem {
    Product product;
    int quantity;
};

// ShoppingCart Ŭ���� ����
class ShoppingCart {
private:
    std::vector<CartItem> items;
public:
    void addItem(const Product& product, int quantity);
    void updateItemQuantity(const std::string& productName, int newQuantity);
    void removeItem(const std::string& productName);
    const std::vector<CartItem>& getItems() const { return items; }
    double calculateTotal() const;
    void clearCart() { items.clear(); } // clearCart() �Լ��� ���⿡ ���ǵǾ� �ֽ��ϴ�.
};
class Order {
public:
    std::vector<CartItem> items;
    double totalAmount;
    std::string paymentMethod; // ���� ���
    std::chrono::system_clock::time_point orderTime; // �ֹ� �ð�
};

class Kiosk {
private:
    std::map<std::string, std::vector<Product>> allProducts;
    ShoppingCart cart;
    std::vector<Order> orderHistory;

public:
    void printHeader() const; 
    void addProduct(const Product& product);
    void run();
    void searchProduct();
    void showCategories();
    void showProductsInCategory(const std::string& categoryName);
    void viewCart();
    void checkout();
    void viewOrders();
    std::string getDeliveryStatus(const Order& order); // ��� ���¸� ��ȯ�ϴ� �Լ�
};

#endif
