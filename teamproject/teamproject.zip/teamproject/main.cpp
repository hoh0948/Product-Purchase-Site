#include "Kiosk.h"
#include <iostream>
#include <iomanip>
#include <windows.h>
#include <thread>   // std::this_thread::sleep_for ����� ���� ����
#include <chrono>   // std::chrono::seconds ����� ���� ����
void SetColor(int color, bool intense = true) {
    if (intense)
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color | FOREGROUND_INTENSITY);
    else
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color); // ���� ���� �� ��ο� ��
}

//===========================================================

void loadKitchenProducts(Kiosk& kiosk);
void loadDailysupplies(Kiosk& kiosk);
void loadsportsProducts(Kiosk& kiosk);
void loadHealthProducts(Kiosk& kiosk);
void loadHomeAppDigital(Kiosk& kiosk);
void loadStationeryProducts(Kiosk& kiosk);
void loadBook(Kiosk& kiosk);
void loadFoodProducts(Kiosk& kiosk);
int main() {
   // SetConsoleOutputCP(CP_UTF8); // �ֿܼ��� �ѱ��� ������ �ʵ��� UTF-8�� ����

    // --- Mopang �ΰ� ��� ���� ---
    // ���� �ڵ� ����
    int DARK_BROWN = FOREGROUND_RED | FOREGROUND_GREEN; // ��ο� ����
    int RED = FOREGROUND_RED;
    int YELLOW = FOREGROUND_RED | FOREGROUND_GREEN;
    int GREEN = FOREGROUND_GREEN;
    int BLUE = FOREGROUND_BLUE;

    std::cout << "\n";

    // ù ��° ��
    SetColor(DARK_BROWN, false); std::cout << "##   ##  ";   // M
    SetColor(DARK_BROWN, false); std::cout << " ####   ";    // O
    SetColor(RED);               std::cout << "#####   ";    // P
    SetColor(YELLOW);            std::cout << "  ###   ";    // A
    SetColor(GREEN);             std::cout << "##   ## ";    // N
    SetColor(BLUE);              std::cout << " #####  \n";  // G

    // �� ��° ��
    SetColor(DARK_BROWN, false); std::cout << "### ###  ";
    SetColor(DARK_BROWN, false); std::cout << "##  ##  ";
    SetColor(RED);               std::cout << "##  ##  ";
    SetColor(YELLOW);            std::cout << " ## ##  ";   // A �� ��° �� ����
    SetColor(GREEN);             std::cout << "###  ## ";
    SetColor(BLUE);              std::cout << "##      \n";

    // �� ��° ��
    SetColor(DARK_BROWN, false); std::cout << "## # ##  ";
    SetColor(DARK_BROWN, false); std::cout << "##  ##  ";
    SetColor(RED);               std::cout << "#####   ";
    SetColor(YELLOW);            std::cout << "## # ## ";   // A �߾��� ���ڷ�
    SetColor(GREEN);             std::cout << "## # ## ";
    SetColor(BLUE);              std::cout << "##  ### \n";

    // �� ��° ��
    SetColor(DARK_BROWN, false); std::cout << "##   ##  ";
    SetColor(DARK_BROWN, false); std::cout << "##  ##  ";
    SetColor(RED);               std::cout << "##      ";
    SetColor(YELLOW);            std::cout << "##   ## ";   // A ���
    SetColor(GREEN);             std::cout << "##  ### ";
    SetColor(BLUE);              std::cout << "##   ## \n";

    // �ټ� ��° ��
    SetColor(DARK_BROWN, false); std::cout << "##   ##  ";
    SetColor(DARK_BROWN, false); std::cout << " ####   ";
    SetColor(RED);               std::cout << "##      ";
    SetColor(YELLOW);            std::cout << "##   ## ";   // A ���
    SetColor(GREEN);             std::cout << "##   ## ";
    SetColor(BLUE);              std::cout << " #####  \n";

    // ���� �⺻��(���) ����
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),
        FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

    std::cout << "\n�ε��� . . . ";
    std::this_thread::sleep_for(std::chrono::seconds(3));
    // --- Mopang �ΰ� ��� ���� ---

    // �ΰ� ��� �� �ܼ� ȭ�� ����� (���� ����)
    system("cls");
    Kiosk myKiosk;

    loadKitchenProducts(myKiosk);
    loadDailysupplies(myKiosk);
    loadsportsProducts(myKiosk);
    loadHealthProducts(myKiosk);
    loadHomeAppDigital(myKiosk);
    loadStationeryProducts(myKiosk);
    loadBook(myKiosk);
    loadFoodProducts(myKiosk);
    
    myKiosk.run();

    return 0;
}